$MAGISK || { for FILE in ${CFGS}; do
               case $FILE in
                 *.conf) sed -i '/vlldp { #$MODID/,/} #$MODID/d' $UNITY$FILE
                         sed -i '/atmos { #$MODID/,/} #$MODID/d' $UNITY$FILE;;
                 *.xml) sed -i '/<!--$MODID-->/d' $UNITY$FILE;;
               esac
             done;
             set_perm /system/bin/audioserver 0 2000 0755 u:object_r:audioserver_exec:s0; }
