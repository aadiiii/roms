if [ "$SEINJECT" != "/sbin/sepolicy-inject" ]; then
  $SEINJECT --live "create dolby_prop dts_data_file hal_audio_default hal_broadcastradio_hwservice" "allow { audioserver hal_audio_default } { default_android_service audioserver_service } service_manager *" "allow { audioserver hal_audio_default priv_app servicemanager } { audio_data_file dts_data_file hal_audio_default system_data_file } dir *" "allow { audioserver hal_audio_default mediaserver priv_app servicemanager system_server } { audioserver audioserver_tmpfs dolby_prop dts_data_file hal_audio_default mediaserver_tmpfs sysfs system_data_file unlabeled } file *" "allow audioserver hal_broadcastradio_hwservice hwservice_manager *" "allow dts_data_file labeledfs filesystem *" "allow { hal_audio_default servicemanager } hal_audio_default process *" "allow hal_audio_default servicemanager binder *" "allow priv_app init unix_stream_socket *" "allow priv_app property_socket sock_file *"  
else
  $SEINJECT -Z audioserver -l
  $SEINJECT -Z hal_audio_default -l
  $SEINJECT -Z mediaserver -l
  $SEINJECT -Z priv_app -l
  $SEINJECT -Z servicemanager -l
  $SEINJECT -Z system_server -l
  $SEINJECT -Z dts_data_file -l  
fi
tinymix=$ROOT/system/bin/tinymix
if [ -f "$tinymix" ]; then
  $tinymix 'DS2 OnOff' '1' 2>/dev/null
  $tinymix 'HiFi Function' 'On' 2>/dev/null
fi
am start -a android.intent.action.MAIN -n com.dolby.dax2appUI/.MainActivity
killall com.dolby.dax2appUI
killall audioserver
