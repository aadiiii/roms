


# Dolby Atmos™ for Android Oreo 2/2/18

# a guitardedhero preparation for ARISE Sound Systems™



• Description:

  • Dolby Atmos™ Digital Signal Processer with effects and Graphic User Interface ported from the latest ZTE™ Axon 7 Android Oreo firmware.

  • Dolby Atmos™ sound effects applied to media audio output supporting various media players.

  • Flexible custom recovery installation archive supporting Magisk including the option to install directly to /system via /sdcard/arise_parameters.prop with the appropriate edit.



• Details:

  • A minimum of SDK 26 (Android 8.0) is required for installation to begin, else Exit 1 will abort the recovery installation activity.

  • Magisk users are provided the option of installing directly to /system instead of creating a Magisk module using the included arise_parameters.prop.

  • Magisk users instructing a /system installation via a prepared /sdcard/arise_parameters.prop are encouraged to confirm a minimum of 100MB of /system space is available before beginning installation in recovery.

  • Magisk users performing the default Magisk module installation will require 100MB more than the minimum available /data space acceptable (usually 500MB, 500MB + 100MB = 600MB).

  • Permissive SELinux Mode is currently required and will be set automatically each device boot. Do not install if this is not acceptable.



• Instructions:

  • Performing a backup of the /system partition in recovery is encouraged for Magisk users instructing a /system installation in recovery:

    • TWRP > Backup > Check System > Edit name, if desired > Swipe to perform backup operation

  • Confirm device requirements are met and installation results are acceptable.

  • Confirm an escape route is available in the event of unsuccessful device boot or unsatisfactory experience.

  • Confirm successful download and location of downloaded archive(s).

    • Boot to recovery > Install > *.zip > Swipe to perform installation operation > Advanced > Copy Log > Reboot

  • Updating procedure is no different unless specified otherwise.



• Support:
 https://forum.xda-developers.com/oneplus-5/themes/app-dolby-atmos-axon-7-oreo-port-t3734040



:good:
